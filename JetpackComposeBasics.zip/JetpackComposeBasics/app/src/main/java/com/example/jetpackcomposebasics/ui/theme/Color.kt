package com.example.jetpackcomposebasics.ui.theme

import androidx.compose.ui.graphics.Color

val LilacPrimary = Color(0xFFE6DAF0)
val LilacDark = Color(0xFFB497D6)
val BeigeBackground = Color(0xFFF5F5DC)

// These are for dark mode fallback (optional)
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
