import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.medapp.ui.theme.screens.BookingScreen
import com.example.medapp.ui.theme.screens.ReportScreen
import com.example.medapp.ui.theme.signupscreen.SignupScreen
import com.medapp.ui.screens.*
import com.medapp.viewmodel.AuthViewModel

@Composable
fun AppNavGraph(
    navController: NavHostController,
    viewModel: AuthViewModel,
    startDestination: String
) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable("signup") { SignupScreen(navController, viewModel) }
        composable("login") { LoginScreen(navController, viewModel) }
        composable("profile") { ProfileScreen(navController, viewModel) }
        composable("reports") { ReportScreen(navController) }
        composable("booking") { BookingScreen(navController) }
    }
}
