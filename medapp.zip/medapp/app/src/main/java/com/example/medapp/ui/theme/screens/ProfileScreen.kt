package com.medapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.medapp.viewmodel.AuthViewModel

@Composable
fun ProfileScreen(navController: NavController, viewModel: AuthViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Welcome to Your Profile", style = MaterialTheme.typography.headlineMedium)

        Button(onClick = { navController.navigate("reports") }, modifier = Modifier.fillMaxWidth()) {
            Text("Upload Report")
        }

        Button(onClick = { navController.navigate("booking") }, modifier = Modifier.fillMaxWidth()) {
            Text("Book Appointment")
        }

        Button(
            onClick = {
                navController.navigate("login") {
                    popUpTo("profile") { inclusive = true }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Logout")
        }
    }
}
