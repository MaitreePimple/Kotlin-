package com.example.medapp.ui.theme.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun ReportScreen(navController: NavController) {
    var reportText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Upload Medical Report", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = reportText,
            onValueChange = { reportText = it },
            label = { Text("Report Details") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = {
            reportText = ""
            navController.navigate("profile")
        }, modifier = Modifier.fillMaxWidth()) {
            Text("Submit")
        }

        TextButton(onClick = { navController.popBackStack() }) {
            Text("Back")
        }
    }
}
