   package com.example.medapp

   import android.os.Bundle
   import androidx.activity.ComponentActivity
   import androidx.activity.compose.setContent
   import androidx.compose.foundation.layout.*
   import androidx.compose.material3.*
   import androidx.compose.runtime.*
   import androidx.compose.ui.Alignment
   import androidx.compose.ui.Modifier
   import androidx.navigation.compose.rememberNavController
   import com.medapp.navigation.AppNavGraph
   import com.medapp.tokenmanager.TokenManager
   import com.medapp.ui.theme.MedappTheme
   import com.medapp.viewmodel.AuthViewModel
   import kotlinx.coroutines.flow.first
   import kotlinx.coroutines.launch

   class MainActivity : ComponentActivity() {
       private lateinit var tokenManager: TokenManager

       override fun onCreate(savedInstanceState: Bundle?) {
           super.onCreate(savedInstanceState)
           tokenManager = TokenManager(applicationContext)

           setContent {
               MedappTheme {
                   var startDestination by remember { mutableStateOf<String?>(null) }

                   // Check login state from DataStore
                   LaunchedEffect(Unit) {
                       val isLoggedIn = tokenManager.isLoggedInFlow.first()
                       startDestination = if (isLoggedIn) "profile" else "signup"
                   }

                   // Show loader until login state is read
                   if (startDestination != null) {
                       val navController = rememberNavController()
                       val viewModel = AuthViewModel()

                       AppNavGraph(
                           navController = navController,
                           viewModel = viewModel,
                           startDestination = startDestination!!
                       )
                   } else {
                       Box(
                           modifier = Modifier.fillMaxSize(),
                           contentAlignment = Alignment.Center
                       ) {
                           CircularProgressIndicator()
                       }
                   }
               }
           }
       }
   }


   @Composable
   fun Greeting(name: String, modifier: Modifier = Modifier) {
       Text(
           text = "Hello $name!",
           modifier = modifier
       )
   }

   @Preview(showBackground = true)
   @Composable
   fun GreetingPreview() {
       MedappTheme {
           Greeting("Android")
       }
   }