package com.medapp.viewmodel

import androidx.lifecycle.ViewModel

class AuthViewModel : ViewModel() {
    private val users = mutableMapOf<String, String>() // email to password

    fun signup(email: String, password: String): Boolean {
        if (email in users) return false
        users[email] = password
        return true
    }

    fun login(email: String, password: String): Boolean {
        return users[email] == password
    }
}
